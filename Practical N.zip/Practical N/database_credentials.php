<?php
//The parameters for the database connect
       define("servername","localhost");
       define("username","root");
       define("password","");
       define("dbname","lab_post");

?>