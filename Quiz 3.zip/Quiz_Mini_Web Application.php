<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device=width, initial-scale=1.0">
    <title>Webtech Form</title>

</head>
<body>
    <h1>Quiz Mini Web Application</h1>
    
    
    <p1>Choose one of the following names:<br/>
    <!--Creating a drop-down list for users to select from -->
        <Select name="Username">
            <option value="Emmanuella">Emmanuella</option>
            <option value="Kenneth">Kenneth</option>
            <option value="Susana">Susana</option>
            <option value="Alberta">Alberta</option>
            <option value="King">King</option>
        </select>
    </p1>

    <p2>Choose one of the following:<br/>
    <!--Creating a drop-down list for users to select from -->
    
        <Select multiple size="5">
            <option value="Football">Emmanuella</option>
            <option value="Banku">Kenneth</option>
            <option value="Rice">Susana</option>
            <option value="Waakye">Alberta</option>
            <option value="Driving">King</option>
        </select>
    </p2>
</body>
</html>
